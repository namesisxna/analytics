package com.cts.self.analytics.plots;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.stereotype.Component;

import com.cts.self.analytics.util.AnalyticsUtil;

@Component("violinplot")
public class ViolinPlot {
    private RConnection conn;
	
	public void createViolinPlot(Exchange exchange) throws REngineException {
		Message input = exchange.getIn();
		String body = input.getBody(String.class);
		//System.out.println(body);
		AnalyticsUtil util = new AnalyticsUtil();
		List<String> params = util.getParam(body);
		//RConnection conn = util.createConnection();
//		System.out.println(params.get(0));
//		System.out.println(params.get(1));
		try {
			REXP r = conn
					.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");"+
							"install.packages(\"vioplot\");"+
							"library(\"vioplot\");"+
							"tp = read.csv(\"D:/version/input.csv\");"+
							"X1 <- tp$len[tp$supp==\"OJ\"];"+
							"X2 <- tp$len[tp$supp==\"VC\"];"+
							"vioplot(X1,X2,names=c(\"orangejuice suppl\",\"vitamin c suppl\"),col=\"orange\");"+
							"dev.off();");
			//REXP r = conn.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");fd2 = read.csv(\"flightdelay2.csv\");boxplot(fd2$"+params.get(0)+"~fd2$"+params.get(1)+"); dev.off()");
			if (r.inherits("try-error"))
				throw new Exception(r.asString());
			else {
				conn.close();
				util.plotGraph( "d://plot1.png", "png");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}



}
