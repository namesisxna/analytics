package com.cts.self.analytics.delegator;

import org.apache.camel.Exchange;
import org.apache.camel.Processor;
import org.apache.camel.builder.RouteBuilder;
import org.springframework.stereotype.Component;

@Component
public class ModelDelegator extends RouteBuilder {

	@Override
	public void configure() throws Exception {

		// TODO Auto-generated method stub
		from("direct:getModel").setBody(constant("hello"));
		from("direct:uploadData")
//		.process(new Processor() {
//			
//			@Override
//			public void process(Exchange exchange) throws Exception {
//				System.out.println(exchange.getIn().getBody(String.class));
//				// TODO Auto-generated method stub
//				
//			}
//		});
		//.unmarshal().mimeMultipart()
		.to("file:D:\\version?fileName=input.csv")
		.bean("util",
				"uploadData($body)");
		from("direct:createboxplot").bean("boxplot", "createBoxPlot");
		from("direct:createdotchart").bean("dotchart", "createdotchart");
		from("direct:createviolinplot").bean("violinplot", "createViolinPlot");
		
		
		

	}

}
