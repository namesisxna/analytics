package com.cts.self.analytics.controller;

import java.awt.image.BufferedImage;
import java.util.Map;

import javax.servlet.annotation.MultipartConfig;

import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.model.rest.RestBindingMode;
import org.springframework.web.bind.annotation.RestController;


@RestController
@MultipartConfig(fileSizeThreshold=1024*1024*10, 	// 10 MB 
maxFileSize=1024*1024*50,      	// 50 MB
maxRequestSize=1024*1024*100) 
public class ModelController extends RouteBuilder {
	
	@Override
	public void configure() throws Exception 
	{
		// TODO Auto-generated method stub
		
	    restConfiguration().component("servlet").host("localhost").bindingMode(RestBindingMode.off);
	    rest()
		.get("/getModel").to("direct:getModel")
		.post("/uploadData").consumes("multipart/form-data").outType(Map.class).to("direct:uploadData")
		.post("/createBoxplot").consumes("application/x-www-form-urlencoded").to("direct:createboxplot")
		.post("/createDotchart").consumes("application/x-www-form-urlencoded").to("direct:createdotchart")
		.post("/createViolinplot").consumes("application/x-www-form-urlencoded").to("direct:createviolinplot");
	   
           
	}
}
