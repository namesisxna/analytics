package com.cts.self.analytics.util;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.imageio.ImageIO;

import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.self.analytics.datatypes.ColumnDetails;

@Component("util")
public class AnalyticsUtil {
    @Autowired
    private RConnection conn;
//	private RConnection conn;
//
//	public RConnection getConn() {
//		return conn;
//	}
//
//	public void setConn(RConnection conn) {
//		this.conn = conn;
//	}
	public AnalyticsUtil(String host, String port) {
//		if (!host.isEmpty() && host != null && !port.isEmpty() && port != null) {
//			int RPort = Integer.valueOf(port);
//			try {
//				setConn(new RConnection(host, RPort));
//			} catch (RserveException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
	}

	public AnalyticsUtil() {
		
	}

	public REXP createDevice(DEVICE_TYPE device,RConnection connection) {
		RConnection conn = connection;

		// device = "jpeg";
		REXP xp = null;
		try {
			conn.parseAndEval("library(\"Cairo\")");
			switch (device) {
			case jpeg:
				xp = conn
						.parseAndEval("try("
								+ "jpeg"
								+ "('test.jpg',width=763,height=600,quality=300,pointsize=12,bg =\"white\",res=500))");
				break;
			case png:
				xp = conn
						.parseAndEval("try("
								+ "Cairo"
								+ "('test.png',width=2048,height=1024,quality=300,pointsize=12,type=\"png\",res=150))");
				break;
			case pdf:
				xp = conn
						.parseAndEval("try("
								+ "Cairo"
								+ "('test.pdf',width=2048,height=1024,quality=300,pointsize=12,type=\"pdf\",res=500))");
				break;
			default:
				break;
			}
			if (xp.inherits("try-error")) {
				System.err.println("Can't open " + device
						+ " graphics device:\n" + xp.asString());
				REXP w = conn
						.eval("if (exists('last.warning') && length(last.warning)>0) names(last.warning)[1] else 0");
				if (w.isString())
					System.err.println(w.asString());
			}
		} catch (REngineException | REXPMismatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return xp;
	}

	public void createdotchart() {
		//RConnection conn = createConnection();
		REXP xp = createDevice(DEVICE_TYPE.jpeg,conn);
		try {
			REXP r = conn
					.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");cardata = read.csv(\"mtcars.csv\");dotchart(cardata$mpg); dev.off()");
			if (r.inherits("try-error"))
				throw new Exception(r.asString());
			else {
				xp = conn
						.parseAndEval("r=readBin('test.jpg','raw',1e8); unlink('test.jpg'); r");
				InputStream in = new ByteArrayInputStream(xp.asBytes());
				BufferedImage bImageFromConvert = ImageIO.read(in);
				ImageIO.write(bImageFromConvert, "jpg", new File(
						"d://plot1.jpg"));
			}
		} catch (REngineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (REXPMismatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	

	public Map<String, String> uploadData(File file) {
		
		ColumnDetails columnDetails = new ColumnDetails();
		String[] colNames = null;
		String[] typeNames = null;
		
		int count = 0;
		Map<String, String> response = new HashMap<String, String>();
		try {
			//RConnection conn = createConnection();
			conn.parseAndEval("tp = read.csv(\"D:/version/input.csv\")");
			REXP rColnames = conn.parseAndEval("names(tp)");
			REXP rType = conn.parseAndEval("sapply(tp,class)");

			colNames = rColnames.asStrings();
			typeNames = rType.asStrings();

			for (String colName : colNames) {
				response.put(colName, typeNames[count]);
				count++;
			}
			columnDetails.setColdata(response);
			conn.close();
		} catch (REngineException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (REXPMismatchException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return response;

	}

	public List<String> getParam(String data) {
		List<String> paramList = new ArrayList<String>();
		if(data!=null&& !data.isEmpty()){
		String[] params = data.split("&");
		for (String s : params) {
			String[] split = s.split("=");
			paramList.add(split[1]);

		}
		}
		return paramList;

	}

	public void plotGraph(String fileName, String deviceType) {
		REXP xp = null;
		AnalyticsUtil util = new AnalyticsUtil();
		RConnection connection =null;
		try {
			 //connection = util.createConnection();
			if (!deviceType.isEmpty() && deviceType != null) {
				if (deviceType.toLowerCase().equals("png")) {
					xp = createDevice(DEVICE_TYPE.png,connection);
					xp = connection
							.parseAndEval("r=readBin('test.png','raw',1e8); unlink('test.png'); r");
					InputStream in = new ByteArrayInputStream(xp.asBytes());
					BufferedImage bImageFromConvert = ImageIO.read(in);
					ImageIO.write(bImageFromConvert, "png", new File(fileName));
				} else if (deviceType.toLowerCase().equals("jpg")) {
					xp = createDevice(DEVICE_TYPE.jpeg,connection);
					xp = connection
							.parseAndEval("r=readBin('test.jpg','raw',1e8); unlink('test.jpg'); r");
					InputStream in = new ByteArrayInputStream(xp.asBytes());
					BufferedImage bImageFromConvert = ImageIO.read(in);
					ImageIO.write(bImageFromConvert, "jpg", new File(fileName));

				} else if (deviceType.toLowerCase().equals("pdf")) {
					xp = createDevice(DEVICE_TYPE.pdf,connection);
					xp = connection
							.parseAndEval("r=readBin('test.pdf','raw',1e8); unlink('test.pdf'); r");
					InputStream in = new ByteArrayInputStream(xp.asBytes());
					BufferedImage bImageFromConvert = ImageIO.read(in);
					ImageIO.write(bImageFromConvert, "pdf", new File(fileName));
				}
			}

		} catch (REngineException | REXPMismatchException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			connection.close();
		}
	}

	public static void main(String[] args) {
		AnalyticsUtil analyticsUtil = new AnalyticsUtil();
		//RConnection conn =  analyticsUtil.createConnection();
		analyticsUtil.createdotchart();
//		try {
//			REXP x = conn.eval("R.version.string");
//			System.out.println(x.asString());
//		} catch (RserveException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (REXPMismatchException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		
	}

}
