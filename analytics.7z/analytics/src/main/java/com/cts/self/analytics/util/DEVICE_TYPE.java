package com.cts.self.analytics.util;

public enum DEVICE_TYPE {
	 jpeg, png,pdf;
}
