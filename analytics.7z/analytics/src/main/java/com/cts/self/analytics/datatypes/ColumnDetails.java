package com.cts.self.analytics.datatypes;

import java.util.Map;

public class ColumnDetails {
	private Map<String, String> columnData;

	public Map<String, String> getColdata() {
		return columnData;
	}

	public void setColdata(Map<String, String> coldata) {
		this.columnData = coldata;
	}
	

}
