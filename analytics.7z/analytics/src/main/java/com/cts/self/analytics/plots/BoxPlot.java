package com.cts.self.analytics.plots;

import java.util.List;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cts.self.analytics.util.AnalyticsUtil;

@Component("boxplot")
public class BoxPlot {

    @Autowired
    private RConnection conn;
	public void createBoxPlot(Exchange exchange) throws REngineException {
		Message input = exchange.getIn();
		String body = input.getBody(String.class);
		System.out.println(body);
		AnalyticsUtil util = new AnalyticsUtil();
		List<String> params = util.getParam(body);
		//RConnection conn = util.createConnection();
		System.out.println(params.get(0));
		System.out.println(params.get(1));
		try {
			REXP r = conn
					.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");tp = read.csv(\"D:/version/input.csv\");boxplot(tp$"
							+ params.get(0)
							+ "~tp$"
							+ params.get(1)
							+ "); dev.off()");
			System.out.println();
			//REXP r = conn.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");fd2 = read.csv(\"flightdelay2.csv\");boxplot(fd2$"+params.get(0)+"~fd2$"+params.get(1)+"); dev.off()");
			if (r.inherits("try-error"))
				throw new Exception(r.asString());
			else {
				conn.close();
				util.plotGraph( "d://plot1.png", "png");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
//	public static void main(String[] args) {
//		AnalyticsUtil util = new AnalyticsUtil();
//		
//		//RConnection conn = util.createConnection();
//	
//		try {
////			REXP r = conn
////					.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");tp = read.csv(\"D:/version/input.csv\");boxplot(tp$"
////							+ params.get(0)
////							+ "~tp$"
////							+ params.get(1)
////							+ "); dev.off()");
//			REXP r = conn.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");fd2 = read.csv(\"flightdelay2.csv\");boxplot(fd2$appears~fd2$airline_name); dev.off()");
//			if (r.inherits("try-error"))
//				throw new Exception(r.asString());
//			else {
//				conn.close();
//				util.plotGraph( "d://plot1.png", "png");
//			}
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} 
//	}
	
	
		
	
}
