package com.cts.self.analytics.plots;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.InputStream;
import java.util.List;

import javax.imageio.ImageIO;

import org.apache.camel.Exchange;
import org.apache.camel.Message;
import org.rosuda.REngine.REXP;
import org.rosuda.REngine.REXPMismatchException;
import org.rosuda.REngine.REngineException;
import org.rosuda.REngine.Rserve.RConnection;
import org.springframework.stereotype.Component;

import com.cts.self.analytics.util.AnalyticsUtil;
import com.cts.self.analytics.util.DEVICE_TYPE;

@Component("dotchart")
public class DotChart {
    private RConnection conn;

	public void createdotchart(Exchange exchange) {
		Message input = exchange.getIn();
		String body = input.getBody(String.class);

		AnalyticsUtil util = new AnalyticsUtil();
		List<String> params = util.getParam(body);
		//RConnection conn = util.createConnection();
		System.out.println(params.get(0));
		 String test = params.get(1).replaceAll("\\+", " ");
		 System.out.println(test);
		
		try {
			REXP r = conn.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");tp = read.csv(\"D:/version/input.csv\");dotchart(tp$"
					+ params.get(0) + ",labels=row.names(tp),cex = 0.7,main=" + "\"" + params.get(1).replaceAll("\\+", " ") + ("\"")
					+ ",xlab="+ "\"" + params.get(2).replaceAll("\\+", " ") + ("\"")+");dev.off()");

			// REXP r = conn.parseAndEval("setwd(\"D:\\\\AIPOC(R)\");fd2 =
			// read.csv(\"flightdelay2.csv\");boxplot(fd2$"+params.get(0)+"~fd2$"+params.get(1)+");
			// dev.off()");
			if (r.inherits("try-error"))
				throw new Exception(r.asString());
			else {
				conn.close();
				util.plotGraph("d://plot1.png", "png");
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

//	public static void main(String[] args) {
//		AnalyticsUtil util = new AnalyticsUtil();
//		RConnection conn = util.createConnection();
//
//		// REXP xp = util.createDevice(DEVICE_TYPE.png, conn);
//		// .parseAndEval("setwd(\"D:\\\\AIPOC(R)\");cardata =
//		// read.csv(\"mtcars.csv\");dotchart(cardata$mpg,labels=row.names(mtcars),cex
//		// = 0.7,main=\"Distribution of mileage for different cars\",xlab =
//		// \"miles per gallon\"); dev.off()");
//		try {
//			REXP r = conn.parseAndEval(
//					"setwd(\"D:\\\\AIPOC(R)\");cardata = read.csv(\"mtcars.csv\");dotchart(cardata$mpg,labels=row.names(cardata),cex = 0.7,main=\"Distribution of mileage for different cars\",xlab=\"miles per gallon\");dev.off()");
//			if (r.inherits("try-error"))
//				throw new Exception(r.asString());
//			else {
//				conn.close();
//				util.plotGraph("d://plot1.png", "png");
//			}
//		} catch (REngineException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (REXPMismatchException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		conn.close();
//
//	}

}
