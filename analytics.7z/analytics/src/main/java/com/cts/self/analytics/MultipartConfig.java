package com.cts.self.analytics;

import javax.servlet.MultipartConfigElement;

import org.apache.camel.CamelContext;
import org.apache.camel.component.servlet.CamelHttpTransportServlet;
import org.apache.camel.spring.SpringCamelContext;
import org.apache.camel.spring.boot.CamelContextConfiguration;
import org.rosuda.REngine.Rserve.RConnection;
import org.rosuda.REngine.Rserve.RserveException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.servlet.MultipartConfigFactory;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MultipartConfig {
    @Bean
    public MultipartConfigElement multipartConfigElement() {
	MultipartConfigFactory factory = new MultipartConfigFactory();
	factory.setMaxFileSize("10MB");
	factory.setMaxRequestSize("10MB");
	return factory.createMultipartConfig();
    }

    @Bean
    public ServletRegistrationBean camelServletRegistrationBean(@Value("${service.name}") String serviceName,
	    @Value("${service.version}") String serviceVersion) {
	ServletRegistrationBean registration = new ServletRegistrationBean(new CamelHttpTransportServlet(),
		String.format("/%s/%s/*", serviceName, serviceVersion));
	registration.setName("CamelServlet");
	return registration;
    }

    @Bean
    CamelContextConfiguration contextConfiguration(@Value("${service.name}") String name) {
	return new CamelContextConfiguration() {
	    @Override
	    public void beforeApplicationStart(CamelContext context) {
		((SpringCamelContext) context).setName(name);
	    }

	    @Override
	    public void afterApplicationStart(CamelContext context) {
	    }
	};
    }

    @Bean
    public RConnection createConnection() {
	RConnection conn = null;
	try {
	    conn = new RConnection();
	} catch (RserveException e) {
	    // TODO Auto-generated catch block
	    e.printStackTrace();
	}
	return conn;

    }

}
